/**************************************************************************************************/
/* Copyright (C) WangQi, SSE@USTC, 2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  WangQi                                                               */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/16                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by WangQi, 2014/09/16
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"

int Help();
tDataNode * head;

/* init linklist */
tDataNode * Init(void)
{
    tDataNode * next,* temp;
    head=( tDataNode *)malloc(LEN);
    temp = head;
    SetDataNode(head,"help","this is help command",Help);

    next = CreateDataNode(temp,"dir","this is dir command",NULL);
    temp=next;

    next = CreateDataNode(temp,"mdelete","this is mdelete command",NULL);
    temp=next;

    next = CreateDataNode(temp,"qc","this is qc command",NULL);
    temp=next;

    next = CreateDataNode(temp,"site","this is site command",NULL);
    temp=next;

    next = CreateDataNode(temp,"disconnect","this is disconnect command",NULL);
    temp=next;

    next = CreateDataNode(temp,"mdir","this is mdir command",NULL);
    temp=next;

    next = CreateDataNode(temp,"sendport","this is sendport command",NULL);
    temp=next;

    next = CreateDataNode(temp,"size","this is size command",NULL);
    temp=next;

    next = CreateDataNode(temp,"account","this is account command",NULL);
    temp=next;

    next = CreateDataNode(temp,"exit","this is exit command",NULL);
    temp=next;

    next = CreateDataNode(temp,"mget","this is mget command",NULL);
    temp=next;

    temp->next = NULL;
    return head;
}

tDataNode * FindCmd(tDataNode * head,char * cmd)
{
    if(head == NULL || cmd == NULL)
    {
        return NULL;
    }
    tDataNode * p=head;
    while(p != NULL)
    {
        if(strcmp(p->cmd, cmd)==0)
        {
            return p;
            break;
        }
        p = p->next;
    }
    return NULL;
}

int FindAllCmd(tDataNode * head)
{
    printf("All commands:\n");
    tDataNode * p = head;
    while(p != NULL)
    {
        printf("%s - %s\n", p->cmd, p->desc);
        p = p->next;
    }
    return 0;
}


int Help()
{
    FindAllCmd(head);
    return 0;
}

void InitList()
{
    Init();
}

void Add(char * cmd,char * desc,int (* Handler)())
{
    tDataNode * next,* temp;
    temp = head;
    next = head->next;
    while(next!=NULL)
    {
        temp = next;
        next = next->next;
    }
    next = CreateDataNode(temp,cmd,desc,Handler);
    temp->next = next;
    temp = next;
    temp->next = NULL;

}
void DoCmd(char * cmd)
{
    const char * help = "help";
    tDataNode * p = FindCmd(head,cmd);
    while(p != NULL)
    {
        if(strcmp(p->cmd, help)==0)
        {
            printf("%s - %s\n", p->cmd, p->desc);
            if(p->handler != NULL)
            {
                p->handler();
            }
            return;
        }
        else
        {
            printf("%s - %s\n", p->cmd, p->desc);
            if(p->handler != NULL)
            {
                p->handler();
            }
            return;
        }
        p = p->next;
    }
    if(p == NULL)
    {
        printf("This is a wrong command!\n ");
    }
}
