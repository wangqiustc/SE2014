/**************************************************************************************************/
/* Copyright (C) WangQi, SSE@USTC, 2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  linklish.c                                                           */
/*  PRINCIPAL AUTHOR      :  WangQi                                                               */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  linklist                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/16                                                           */
/*  DESCRIPTION           :  This is a linklist for menu program                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by WangQi, 2014/09/16
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linktable.h"

/* set nodes of linklist */
void SetDataNode(tDataNode * pDataNode,char * cmd,char * desc,int (* Handler)())
{
    pDataNode->cmd = cmd;
    pDataNode->desc = desc;
    pDataNode->handler = Handler;
}

/* create linklist */
tDataNode * CreateDataNode(tDataNode * pDataNode,char * cmd,char * desc,int (* Handler)())
{
    tDataNode * next;
    next = (tDataNode *)malloc(LEN);
    pDataNode->next = next;
    SetDataNode(next,cmd,desc,Handler);
    return next;
}