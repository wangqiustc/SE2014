#include<stdio.h>
#include"menu.h"

/* do test command */
int TestCmd()
{
    printf("do test command\n");
    return 0;
}
void main()
{
    InitList();
    Add("test","this is test command",TestCmd);
    while(1)
    {
	char cmd[CMD_MAX_LEN];
        printf("Please input a command > ");
        scanf("%s", cmd);
        DoCmd(cmd);
    }
}
