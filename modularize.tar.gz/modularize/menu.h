#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define LEN  2048

void InitList();
void Add(char * cmd,char * desc,int (* Handler)());
void DoCmd(char * cmd);