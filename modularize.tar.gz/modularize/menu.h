#include "linktable.h"
#define CMD_MAX_LEN 128
#define DESC_LEN 1024

tDataNode * FindCmd(tDataNode * head,char * cmd);
int FindAllCmd(tDataNode * head);
int Help();
void InitList();
void Add(char * cmd,char * desc,int (* Handler)());
void DoCmd(char * cmd);