#define LEN  2048

/* define struct */
typedef struct DataNode
{
    char    * cmd;
    char    * desc;
    int     (* handler)();
    struct  DataNode * next;
} tDataNode;

void SetDataNode(tDataNode * pDataNode,char * cmd,char * desc,int (* Handler)());
tDataNode * CreateDataNode(tDataNode * pDataNode,char * cmd,char * desc,int (* Handler)());