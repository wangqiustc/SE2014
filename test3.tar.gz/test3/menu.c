/**************************************************************************************************/
/* Copyright (C) WangQi, SSE@USTC, 2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  WangQi                                                               */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/26                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by WangQi, 2014/09/26
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"


int SearchNode(tLinkTableNode *pNode,void* cmd);

/* initialize the command */
int CreateMenu(tLinkTable* head,tDataNode data[])
{
    if(data->cmd!=NULL && data->desc!=NULL)
    {
        int i;
        for(i = 0; i<7; i++)
        {
            if(data[i].cmd != NULL)
            {
                AddLinkTableNode(head,(tLinkTableNode *)&data[i]);
            }
            else
            {
                break;
            }
        }
        return 0;
    }
    else
    {
        return -1;
    }

}

/* find a command */
tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return pNode;
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}

/* show all commands */
int FindAllCmd(tLinkTable * head)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;
}

/* add a command */
int AddCmd(tLinkTable * head, char * cmd,char * desc)
{
    if(* cmd != '\0' && * desc != '\0')
    {
        tDataNode *tNode = (tDataNode*) malloc(sizeof(tDataNode));
        tNode->cmd = cmd;
        tNode->desc = desc;
        tNode->pNext = NULL;
        tNode->handler = NULL;
        AddLinkTableNode(head,(tLinkTableNode *)tNode);
        return 0;
    }
    else
    {
        return -1;
    }
}

/* delete a command */
int DelCmd(tLinkTable * p,char * cmd)
{
    if(p == NULL || cmd == NULL)
    {
        return 0;
    }
    tLinkTableNode * tNode=SearchLinkTableNode(p, SearchNode, (void*) cmd);
    DelLinkTableNode(p,tNode);
    return 0;
}

/* Modify a command */
int ModCmd(tLinkTable * p,char * cmd,char * desc)
{
    if(p == NULL || cmd == NULL || desc ==NULL)
    {
        return -1;
    }
    tLinkTableNode * tNode=SearchLinkTableNode(p, SearchNode, (void*) cmd);
    ((tDataNode *)tNode)->cmd=cmd;
    ((tDataNode *)tNode)->cmd=desc;
    return 0;
}

/* search a command */
int SearchCmd(tLinkTable * head,char * cmd)
{
    tDataNode *tNode=(tDataNode*) SearchLinkTableNode(head, SearchNode, (void*) cmd);
    if(tNode == NULL)
    {
        return -1;
    }
    else
    {
        return 0;
    }
}

int SearchNode(tLinkTableNode *pNode,void * cmd)
{
    if(!strcmp(((tDataNode*) pNode) -> cmd, (char*) cmd))
    {
        return 0;
    }
    else
    {
        return -1;
    }
}

/* start the menu */
int  MenuStart(tLinkTable * head)
{
    while (1)
    {
        char cmd[MAX_SIZE];
        printf("Please input a command > ");
        scanf("%s",cmd);
        tDataNode *p = FindCmd(head,cmd);
        if (p == NULL)
        {
            printf("This is a wrong command!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);
        printf("--------------------------------------\n");
        if (p->handler != NULL)
        {
            p->handler(head);
        }
    }
    return 0;
}

int Help(tLinkTable * head)
{
    FindAllCmd(head);
    return 0;
}

/* quit the program */
int Quit(tLinkTable * head)
{
    exit(0);
    return 0;
}
