This is a test program

Build Procedure:
    Get into the folder test3,then input command as follows.
    One Way: 
    $  make  
    $ ./test   
    Another Way:
    $ gcc linktable.c testcase.c teststub.c -o test
    $ ./test   
    # Test Report will display.
